# Alya — A Little World Made Just for You

A self-contained, eight-chapter birthday surprise built with HTML, CSS and JavaScript. No build step or package install is required.

## Run locally

Open this folder in VS Code and use Live Server on `index.html`, or start a local server from this folder:

```powershell
python -m http.server 8000
```

Then visit `http://localhost:8000`. ES modules need a local HTTP server; opening the HTML directly with `file://` is not supported.

## Journey

`index.html` → `welcome.html` → `letter.html` → `memories.html` → `special.html` → `cake.html` → `gift.html` → `final.html`

Navigation, responsive layout, the invitation envelope, typewriter letter/reveal, scrapbook lightbox, cake wish/reset, gift reveal, replay, and keyboard lightbox controls are included. The optional GSAP and Lucide CDN enhancements have CSS/Unicode fallbacks for the main experience.

## Make it personal

- Update recipient/sender, letter text, gallery captions and card messages in `js/config.js`.
- The scrapbook is configured for Alya’s 5 supplied photographs in `assets/images/alya-01.png` through `alya-05.png`. Replace those files or add more entries to `galleryPhotos`, `galleryCaptions`, and `galleryDates` in `config.js`. The Memories chapter also reads its Instagram URL, local music playlist, game screenshots/link, group photo/members/messages, timeline, and surprise note from that configuration. These items start as editable placeholders; no private messages or profile links are assumed.
- The Memories music player only starts after a click. Since each chapter is a separate HTML page, an audio element cannot reliably continue through navigation without changing the site's shared page-navigation architecture; this update keeps playback scoped to Memories and leaves the other chapters intact.
- Add an optional soundtrack at `assets/audio/birthday-music.mp3`. Sound never starts automatically. If the file is absent, the music control explains where to add it.
- The Google Fonts, GSAP and Lucide enhancements use CDNs; a network connection is needed for those enhancements. The main page styling and interactions otherwise work locally.

## Accessibility and motion

Semantic landmarks, visible keyboard focus, accessible dialog controls, image alt text, reduced-motion support and keyboard-operable gallery cards are included. Some optional decorative assets may be blocked offline; the page remains usable.
