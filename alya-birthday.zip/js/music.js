import { config } from "./config.js";

let audio;
let fadeTimer;
let volume = 0.35;

function showMessage(message) {
  const toast = document.querySelector(".toast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("is-visible");
  window.setTimeout(() => toast.classList.remove("is-visible"), 3200);
}

function fadeTo(target, onComplete) {
  window.clearInterval(fadeTimer);
  const start = audio.volume;
  const startedAt = performance.now();
  fadeTimer = window.setInterval(() => {
    const progress = Math.min((performance.now() - startedAt) / 350, 1);
    audio.volume = start + (target - start) * progress;
    if (progress === 1) {
      window.clearInterval(fadeTimer);
      onComplete?.();
    }
  }, 24);
}

export function initMusic() {
  const button = document.querySelector('[data-action="music"]');
  const slider = document.querySelector("#music-volume");
  if (!button || !slider) return;
  try {
    const savedVolume = localStorage.getItem("alya-music-volume");
    if (savedVolume !== null && Number.isFinite(Number(savedVolume))) volume = Number(savedVolume);
  } catch (error) {
    showMessage("Your browser won't save music preferences, but the page is still ready to enjoy.");
    console.info("Music volume preference could not be read.", error);
  }
  slider.value = String(volume);
  audio = new Audio(config.musicPath);
  audio.loop = true;
  audio.preload = "none";
  audio.volume = 0;
  audio.addEventListener("error", () => {
    button.dataset.available = "false";
  }, { once: true });

  slider.addEventListener("input", () => {
    volume = Number(slider.value);
    try {
      localStorage.setItem("alya-music-volume", String(volume));
    } catch (error) {
      showMessage("Your browser won't save music preferences between chapters.");
      console.info("Music volume preference could not be saved.", error);
    }
    if (audio && !audio.paused) audio.volume = volume;
  });
  button.addEventListener("click", async () => {
    if (button.getAttribute("aria-pressed") === "true") {
      button.setAttribute("aria-pressed", "false");
      button.setAttribute("aria-label", "Play birthday music");
      button.title = "Play birthday music";
      fadeTo(0, () => audio.pause());
      return;
    }
    try {
      await audio.play();
      fadeTo(volume);
      button.setAttribute("aria-pressed", "true");
      button.setAttribute("aria-label", "Pause birthday music");
      button.title = "Pause birthday music";
    } catch (error) {
      button.setAttribute("aria-pressed", "false");
      showMessage("Add your music file at assets/audio/birthday-music.mp3 to turn on the soundtrack.");
      console.info("Birthday music is unavailable until the configured audio file is added.", error);
    }
  });
}
