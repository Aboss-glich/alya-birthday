import { config } from "./config.js";
import { renderNavigation, renderFooter } from "./navigation.js";
import { animateEnter, burstConfetti, launchFireworks, revealOnScroll, startAmbientDecor } from "./animation-engine.js";
import { initGallery } from "./gallery.js";
import { initCake } from "./cake.js";
import { initGift } from "./gift.js";
import { initMusic } from "./music.js";
import { initMemoriesExperience } from "./memories-experience.js";

const app = document.querySelector("#app");
const page = app?.dataset.page || "index";
const name = config.recipientName;

function chapter(pageTitle, eyebrow, copy, content, options = {}) {
  const theme = options.theme || "";
  const nav = page === "index" ? "" : renderNavigation(page);
  const footer = page === "index" || page === "final" ? "" : renderFooter(page);
  return `${nav}<div class="site-main ambient-page ${theme}">
    ${content}
  </div>${footer}`;
}

function welcomePage() {
  const copy = `Well, look who's having her special day today! It's YOU, ${name}! 🌸

Aaj ka din sirf calendar ki ek normal date nahi hai. It's a little reminder to celebrate someone who deserves countless reasons to smile. I hope today brings you the kind of happiness that stays long after the candles are blown out, the kind of laughter that makes your cheeks hurt, and the kind of memories that you will always love looking back on.

May this new chapter of your life be filled with beautiful surprises, exciting opportunities, genuine people, endless adventures and moments that make you feel proud of yourself.

So forget everything for a moment, enjoy your special day, smile a little extra and get ready because there's a whole little world of surprises waiting for you here.

Happy Birthday, ${name}! You deserve a beautiful day and an even more beautiful year ahead. 💗`;
  return chapter("Birthday", "", "", `
    <section class="page-container welcome-hero">
      <div class="welcome-copy">
        <span class="eyebrow">A day as lovely as you</span>
        <h1 class="gradient-text">Happiest<br>Birthday,<br>${name}!</h1>
        <p class="script" style="font-size:1.75rem;color:var(--lavender-500)">Today, the universe celebrates YOU. 🌷</p>
        <p class="prose">${copy}</p>
        <a class="button" href="letter.html">Let's Explore Your Surprise <span aria-hidden="true">→</span></a>
      </div>
      <div class="birthday-art welcome-art" aria-label="Illustration of a birthday cake, balloons and flowers">
        <div class="art-orbit"></div><span class="art-sun">✦</span>
        <span class="balloon one"></span><span class="balloon two"></span><span class="balloon three"></span>
        <div class="cake-illustration floaty" aria-hidden="true"><div class="layer bottom"></div><div class="layer top"></div><span class="candle"></span><span class="flame"></span><span class="berry">🍓</span><span class="berry b2">🍓</span></div>
        <span class="floating-decor" style="top:72%;left:10%">✿</span><span class="floating-decor" style="right:9%;bottom:16%;animation-delay:-2s">♡</span>
      </div>
    </section>
  `);
}

function letterPage() {
  const fullLetter = config.letterContent;
  return chapter("Letter", "", "", `
    <section class="page-container">
      <header class="chapter-intro"><span class="eyebrow">Chapter two · a few words from the heart</span><h1>A Little Letter For You <span class="gradient-text">💌</span></h1><p>Some feelings are better written than spoken.</p></header>
      <div class="letter-actions"><button class="button button-secondary" data-action="reveal-letter" aria-expanded="false">Read the letter ✨</button></div>
      <article class="letter-paper reveal" aria-label="Birthday letter">
        <div class="letter-body" data-letter>${escapeHtml(fullLetter)}</div>
        <div class="letter-signature">With lots of good wishes,<br>${escapeHtml(config.senderName)}.</div>
      </article>
    </section>`);
}

function memoriesPage() {
  const photos = config.galleryPhotos.map((source, index) => `
    <figure class="polaroid memory-photo reveal" tabindex="0" role="button" aria-label="Open memory photo ${index + 1}" data-caption="${escapeHtml(`${config.galleryCaptions[index]} · ${config.galleryDates[index]}`)}">
      <span class="tape" aria-hidden="true"></span><span class="memory-heart" aria-hidden="true">♡</span>
      <img src="${escapeHtml(source)}" alt="${escapeHtml(config.galleryCaptions[index])}" loading="lazy" width="600" height="650">
      <figcaption>${escapeHtml(config.galleryCaptions[index])}<small>${escapeHtml(config.galleryDates[index])}</small></figcaption>
    </figure>`).join("");
  const gameCards = config.gamingMemories.map((item, index) => `
    <article class="game-memory reveal">
      <button class="game-memory-toggle" type="button" aria-expanded="false">
        <span class="game-screen">${item.image ? `<img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.caption)}" loading="lazy">` : `<span class="game-placeholder" aria-hidden="true"><span>✦</span><i>+</i><small>ADD SCREENSHOT</small></span>`}</span>
        <span class="game-card-copy"><span class="game-index">MATCH MEMORY 0${index + 1}</span><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(item.caption)}</span><span class="game-open">Tap to reveal <span aria-hidden="true">↗</span></span></span>
      </button>
      <p class="game-note" hidden>${escapeHtml(item.description)}</p>
    </article>`).join("");
  const friends = config.groupMembers.map((friend, index) => `
    <article class="friend-wish reveal">
      <button class="friend-wish-toggle" type="button" aria-expanded="false">
        <span class="anime-avatar avatar-${index + 1}" aria-hidden="true">${friend.image ? `<img src="${escapeHtml(friend.image)}" alt="">` : `<span class="avatar-hair"></span><span class="avatar-face"><i></i><i></i><b></b></span><span class="avatar-blush"></span>`}</span>
        <span class="friend-wish-copy"><span class="friend-label">A birthday note from</span><strong>${escapeHtml(friend.name)}</strong><span class="friend-reveal-label">Tap to open ✨</span></span>
        <span class="wish-heart" aria-hidden="true">♡</span>
      </button>
      <p class="friend-hidden-message" hidden>${escapeHtml(friend.hiddenMessage)}</p>
    </article>`).join("");
  const groupPhoto = config.groupPhoto;
  const groupMessages = config.groupMessages.map((message, index) => `<p class="chat-memory chat-memory-${index + 1} reveal"><span class="chat-dot" aria-hidden="true">♡</span>${escapeHtml(message)}</p>`).join("");
  const timeline = config.memoryTimeline.map((item, index) => `
    <article class="timeline-item reveal">
      <span class="timeline-dot" aria-hidden="true">${["♡", "✦", "✿", "🎂", "✨"][index % 5]}</span>
      <div class="timeline-card">
        <span class="timeline-meta">${escapeHtml(item.category)} <i>·</i> ${escapeHtml(item.date)}</span>
        ${item.image ? `<img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.title)}" loading="lazy">` : `<span class="timeline-placeholder" aria-hidden="true">✧</span>`}
        <h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.description)}</p>
      </div>
    </article>`).join("");
  const instagramUrl = safeExternalUrl(config.alyaInstagramURL);
  const instagramAction = instagramUrl
    ? `<a class="button button-secondary social-button" href="${instagramUrl}" target="_blank" rel="noopener noreferrer">Follow on Instagram <span aria-hidden="true">↗</span></a>`
    : `<button class="button button-secondary social-button" type="button" data-action="instagram-link">Follow on Instagram <span aria-hidden="true">↗</span></button>`;
  const gamingUrl = safeExternalUrl(config.gamingLinks.playTogetherURL);
  const playTogether = gamingUrl
    ? `<a class="button game-invite-button" href="${gamingUrl}" target="_blank" rel="noopener noreferrer">Play Together Again <span aria-hidden="true">↗</span></a>`
    : `<button class="button game-invite-button" type="button" data-action="play-together">Play Together Again <span aria-hidden="true">♡</span></button>`;
  const extraSocials = (config.socialLinks || []).map((link) => {
    const url = safeExternalUrl(link.url);
    return url ? `<a class="social-chip" href="${url}" target="_blank" rel="noopener noreferrer">${escapeHtml(link.label)} ↗</a>` : "";
  }).join("");
  const surpriseText = config.surpriseMessages[0] || "Add a friendship message for Alya here.";
  return chapter("Memories", "", "", `
    <section class="page-container memory-world">
      <header class="memory-hero">
        <div class="memory-hero-copy"><span class="eyebrow">Chapter three · photos, pixels & people</span><h1>A Little World Full of Beautiful <span class="gradient-text">Memories</span> 💗</h1><p>A little scrapbook universe for Alya's photos, game nights, and the friends who make this world feel like ours.</p><a class="button" href="#instagram-memories">Start Exploring <span aria-hidden="true">↓</span></a></div>
        <div class="memory-hero-art" aria-hidden="true">
          <span class="hero-orbit"></span><span class="hero-photo hero-photo-one"><img src="${escapeHtml(config.galleryPhotos[0])}" alt="" loading="lazy"></span><span class="hero-photo hero-photo-two"><img src="${escapeHtml(config.galleryPhotos[1] || config.galleryPhotos[0])}" alt="" loading="lazy"></span><span class="hero-photo hero-photo-three"><img src="${escapeHtml(config.galleryPhotos[2] || config.galleryPhotos[0])}" alt="" loading="lazy"></span>
          <span class="hero-butterfly">🦋</span><span class="hero-star hero-star-one">✦</span><span class="hero-star hero-star-two">✧</span><span class="hero-heart">♡</span>
        </div>
      </header>
      <div class="memory-player" aria-label="Memory music player">
        <div class="player-orb" aria-hidden="true">♫</div>
        <div class="player-info"><span class="player-label">A LITTLE SOUNDTRACK</span><strong data-track-title>No tracks added yet</strong><small data-player-status>Add audio files to assets/audio and list them in js/config.js.</small></div>
        <div class="player-visualizer" aria-hidden="true">${Array.from({ length: 11 }, (_, i) => `<i style="--bar:${i}"></i>`).join("")}</div>
        <div class="player-controls">
          <button class="player-button" type="button" data-action="previous-track" aria-label="Previous track" disabled>‹</button>
          <button class="player-button player-play" type="button" data-action="toggle-player" aria-label="Play music" aria-pressed="false">▶</button>
          <button class="player-button" type="button" data-action="next-track" aria-label="Next track" disabled>›</button>
        </div>
        <label class="sr-only" for="memory-volume">Music volume</label><input id="memory-volume" class="player-volume" type="range" min="0" max="1" step=".05" value=".45" aria-label="Music volume">
      </div>
      <nav class="memory-jump" aria-label="Memories page sections">
        <a href="#instagram-memories"><span>♡</span> Instagram</a><a href="#freefire-memories"><span>✦</span> Free Fire</a><a href="#friends-memories"><span>✿</span> Our group</a><a href="#memory-timeline"><span>⌁</span> Timeline</a>
      </nav>
      <section class="memory-section instagram-section" id="instagram-memories" aria-labelledby="instagram-heading">
        <header class="memory-section-heading"><span class="section-kicker">01 · little squares of joy</span><h2 id="instagram-heading">Alya on <span class="gradient-text">Instagram</span> 📸</h2><p>A few lovely snapshots, collected like little notes from Alya's photo album.</p>
          <div class="instagram-profile"><span class="instagram-avatar" aria-hidden="true">◎</span><span class="instagram-profile-copy"><strong>${escapeHtml(name)}</strong><small>A little photo scrapbook</small></span>${instagramAction}</div>
          ${extraSocials ? `<div class="social-links">${extraSocials}</div>` : ""}
        </header>
        <div class="gallery-grid memory-gallery" aria-label="Instagram-inspired scrapbook gallery">${photos}</div>
        <span class="section-doodle doodle-heart" aria-hidden="true">♡</span><span class="section-doodle doodle-flower" aria-hidden="true">✿</span>
      </section>
      <section class="memory-section freefire-section" id="freefire-memories" aria-labelledby="freefire-heading">
        <header class="memory-section-heading"><span class="section-kicker">02 · one more round?</span><h2 id="freefire-heading">Free Fire <span class="gradient-text">Memories</span> 🎮</h2><p>Room for the screenshots, squad wins, and funny match moments you want to remember.</p></header>
        <div class="game-memory-grid">${gameCards}</div>
        <div class="squad-note"><span class="squad-note-icon" aria-hidden="true">✧</span><p><strong>Your squad's corner</strong><br>Add your own match moments or inside jokes in the editable memory settings.</p><span class="squad-note-icon" aria-hidden="true">♡</span></div>
        <div class="game-invite">${playTogether}<p data-game-message role="status" aria-live="polite"></p></div>
      </section>
      <section class="memory-section friends-section" id="friends-memories" aria-labelledby="friends-heading">
        <header class="memory-section-heading"><span class="section-kicker">03 · our little corner of the world</span><h2 id="friends-heading">${escapeHtml(config.groupName)} <span>💬</span></h2><p>A little spot for the group photo, familiar faces, shared laughs, and birthday wishes from the GC.</p></header>
        <div class="group-scrapbook">
          <div class="group-photo-card">
            <span class="group-tape" aria-hidden="true"></span>
            ${groupPhoto ? `<img src="${escapeHtml(groupPhoto)}" alt="Group photo" loading="lazy">` : `<div class="group-photo-placeholder"><span aria-hidden="true">✿</span><strong>Our group photo goes here</strong><small>Add a photo of your group in the editable memory settings.</small></div>`}
            <span class="group-photo-caption">our gc · our memories ♡</span>
          </div>
          <div class="group-chat-note"><span class="chat-note-sparkle" aria-hidden="true">✧</span><p>Chat bubbles, funny memories, and inside jokes belong here.</p><div class="chat-memory-list">${groupMessages}</div></div>
        </div>
        <div class="friend-wishes" aria-label="Editable birthday wishes from friends">${friends}</div>
        <blockquote class="group-appreciation">${escapeHtml(config.groupAppreciation)} <span>💗</span></blockquote>
        <p class="memory-edit-hint">Names, photos and messages are placeholders—make them yours in <code>js/config.js</code>.</p>
      </section>
      <section class="memory-section timeline-section" id="memory-timeline" aria-labelledby="timeline-heading">
        <header class="memory-section-heading"><span class="section-kicker">04 · little moments, along the way</span><h2 id="timeline-heading">Our Memory <span class="gradient-text">Timeline</span> ✨</h2><p>Leave a breadcrumb for a photo, game night, group moment, or birthday worth remembering.</p></header>
        <div class="memory-timeline">${timeline}</div>
      </section>
      <section class="surprise-section" aria-labelledby="surprise-heading">
        <div class="surprise-copy"><span class="section-kicker">A tiny keepsake, tucked away</span><h2 id="surprise-heading">Surprise Memory Box 🎁</h2><p>There's a little note waiting inside. Open it when you're ready.</p></div>
        <button class="surprise-box" type="button" data-action="open-memory-box" aria-expanded="false" aria-label="Open the surprise memory box">
          <span class="surprise-lid"><i></i></span><span class="surprise-body"><i></i><b>♡</b></span><span class="surprise-bow" aria-hidden="true">✿</span>
        </button>
        <div class="surprise-reveal" data-surprise-reveal hidden><p>${escapeHtml(surpriseText)}</p>${config.memoryTimeline[0]?.image ? `<img src="${escapeHtml(config.memoryTimeline[0].image)}" alt="A memory tucked inside the box" loading="lazy">` : ""}</div>
      </section>
      <section class="friendship-ending" aria-labelledby="ending-heading">
        <span class="ending-moon" aria-hidden="true">☾</span><span class="ending-spark ending-spark-one" aria-hidden="true">✦</span><span class="ending-spark ending-spark-two" aria-hidden="true">✧</span>
        <span class="section-kicker">Until the next little memory</span><h2 id="ending-heading">Our Little World, Always</h2>
        <p>Some memories are captured in photographs, some live in our conversations, and some stay special simply because of the people who were part of them. Thank you for being a beautiful part of our little world, ${escapeHtml(name)}.</p>
        <button class="button replay-memories" type="button" data-action="replay-memories">Replay Our Memories <span aria-hidden="true">↑</span></button>
      </section>
      <div class="lightbox" role="dialog" aria-modal="true" aria-label="Instagram memory photo viewer" hidden>
        <button class="icon-button" data-action="previous-photo" aria-label="Previous photo"><i data-lucide="chevron-left">‹</i></button>
        <figure><img src="" alt=""><figcaption></figcaption></figure>
        <button class="icon-button" data-action="next-photo" aria-label="Next photo"><i data-lucide="chevron-right">›</i></button>
        <button class="icon-button lightbox-close" data-action="close-lightbox" aria-label="Close photo viewer"><i data-lucide="x">×</i></button>
      </div>
    </section>`);
}

function safeExternalUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:" ? escapeHtml(url.href) : "";
  } catch {
    return "";
  }
}

function specialPage() {
  const paragraph = `There's something beautiful about being a person who doesn't have to pretend to be someone else. Your personality, your little habits, your way of looking at things and the unique qualities you carry all make you who you are.

Never feel that you have to become someone else just to fit into a particular place. The world is already full of copies; your individuality is what makes you special.

I hope you always find people who appreciate your kindness, respect your dreams, support your growth and celebrate your happiness.

May you always have the courage to try new things, the confidence to believe in yourself and the patience to keep moving forward even when things take time.

Don't forget to celebrate your little achievements too. Every step counts, every effort matters and every new day is another opportunity to become the person you want to be.

Keep shining in your own beautiful way, ${name}. ✨`;
  const cards = config.specialMessages.map((item, index) => `<article class="special-card card reveal" tabindex="0" style="--delay:${index * 70}ms"><span class="card-icon" aria-hidden="true">${item.icon}</span><h2>${item.title}</h2><p>${item.message}</p></article>`).join("");
  return chapter("You", "", "", `
    <section class="page-container">
      <header class="chapter-intro"><span class="eyebrow">Chapter four · a little reminder</span><h1>Things That Make <span class="gradient-text">You, You!</span> 🌸</h1><p>${paragraph}</p></header>
      <div class="special-grid">${cards}</div>
      <blockquote class="quote-panel reveal">“Never forget the beautiful things that make you YOU. 💗”</blockquote>
    </section>`);
}

function cakePage() {
  const copy = `Okayyy ${name}, enough reading for a moment! It's officially cake time! 🥳

Imagine all your favourite things coming together: a beautiful cake, lots of happiness, your favourite people, endless laughter and a day that gives you a hundred reasons to smile.

Before you blow out those candles, take a moment and make a wish. It could be something big, something small, a dream you've been holding close or something you've never told anyone.

Whatever it is, I hope this year takes you one step closer to it.

Now close your eyes, make that wish and let's make this birthday celebration a little more magical!`;
  return chapter("Cake", "", "", `
    <section class="page-container cake-layout">
      <div class="cake-stage"><div class="interactive-cake" role="img" aria-label="Three-layer pink and lavender birthday cake with three candles">
        <div class="cake-plate"></div><div class="cake-tier bottom"></div><div class="cake-tier middle"></div><div class="cake-tier top"></div>
        <div class="candle-set"><span class="candle"><i class="flame"></i></span><span class="candle"><i class="flame"></i></span><span class="candle"><i class="flame"></i></span></div>
      </div></div>
      <div class="cake-copy"><span class="eyebrow">Chapter five · make a wish</span><h1>Now It's <span class="gradient-text">Cake Time!</span> 🎂</h1>
        <p>${copy}</p>
        <button class="button" data-action="blow-candles">Blow the Candles 💨</button>
        <button class="button button-quiet" data-action="reset-cake" style="margin-left:.5rem">Reset cake ↻</button>
        <div class="celebration-message" role="status" aria-live="polite">YAYYY! 🥳<br><br>May every beautiful wish of yours come true.<br>Stay happy, stay blessed and keep shining!</div>
      </div>
    </section>`);
}

function giftPage() {
  const copy = `Well, you didn't think the surprises were over already, did you? There's always room for one more little happy moment.

This gift isn't about how big or expensive something is. It's about the thought behind it, the time spent creating it and the happiness of knowing that someone took a little extra effort to make your day feel different.

So here's one small reminder for you: never stop believing in your dreams, never underestimate your own potential and never forget that you deserve kindness, respect and happiness.

I hope this little surprise adds one more smile to your birthday. 💗`;
  const message = `${name}, I hope your life is always filled with beautiful moments, genuine happiness, good people and endless opportunities.

You deserve all the good things life has to offer.

Never stop smiling and keep shining! 💗`;
  return chapter("Gift", "", "", `
    <section class="page-container gift-layout">
      <div class="gift-stage" aria-label="A wrapped birthday gift">
        <div class="gift-message" role="status" aria-live="polite"><p>${message}</p></div>
        <div class="gift-box" aria-hidden="true"><div class="gift-base"></div><div class="gift-lid"></div><div class="gift-bow"></div><span class="gift-heart">♥</span></div>
      </div>
      <div class="gift-copy"><span class="eyebrow">Chapter six · just one more thing</span><h1>One Last Little <span class="gradient-text">Surprise...</span></h1>
        <p>${copy}</p><button class="button" data-action="open-gift" aria-expanded="false">Unwrap Your Gift 🎁</button>
      </div>
    </section>`);
}

function finalPage() {
  const copy = `And just like that, we've reached the end of this little birthday journey.

I hope every page brought you a smile, every surprise made you curious and every message reminded you how much happiness you deserve.

${name}, as you step into another year of your life, I hope you discover new things, meet wonderful people, achieve goals that once seemed impossible and collect countless memories worth remembering.

${config.finalMessage}

Never stop exploring the world, never stop learning, and never stop finding reasons to smile.

Thank you for taking a little time to explore this small world created especially for you.

This website may have eight pages, countless animations and a hundred little details, but its entire purpose was simple: to make your birthday a little more memorable.

Once again, Happiest Birthday, ${name}!

Stay happy. Stay blessed. Keep shining. 🌷`;
  return chapter("The End", "", "", `
    <section class="page-container final-page-content">
      <div class="star-field" aria-hidden="true">${Array.from({ length: 28 }, (_, i) => `<span style="left:${(i * 37 + 8) % 97}%;top:${(i * 53 + 7) % 83}%;animation-delay:${(i % 7) * .34}s">✦</span>`).join("")}</div>
      <span class="moon" aria-hidden="true"></span>
      <header class="chapter-intro"><span class="eyebrow">The final chapter · but never the end of the good things</span><h1>Some Wishes Are Too Beautiful To Fit Into Just One Message. <span>💖</span></h1></header>
      <p class="final-copy">${copy}</p>
      <div class="final-signature">Made with lots of care, just for you.<br><br>With lots of good wishes,<br>${escapeHtml(config.senderName)}.</div>
      <div style="text-align:center"><a class="button" href="index.html" data-action="replay">Experience The Magic Again ↻</a></div>
      <footer class="chapter-footer final-footer"><span>Some people deserve their own little universe. ✨</span></footer>
    </section>`, { theme: "final-page" });
}

function invitationPage() {
  return `<section class="invitation ambient-page">
    <span class="floating-decor" style="top:14%;left:14%">✦</span><span class="floating-decor" style="top:24%;right:17%;animation-delay:-2s">♡</span>
    <span class="floating-decor" style="bottom:16%;left:18%;animation-delay:-1s">✿</span><span class="floating-decor" style="bottom:22%;right:14%;animation-delay:-3s">✧</span>
    <div class="orb" style="top:8%;left:4%"></div><div class="orb" style="right:5%;bottom:5%;animation-delay:-3s"></div>
    <div class="invitation-copy"><span class="eyebrow">A little secret, just for you</span><h1 class="script gradient-text">pssst... ${name}! 💗</h1>
      <p>Ek chhoti si surprise hai tumhare liye.</p><p>Someone has prepared a little world just for you.</p>
    </div>
    <div class="envelope-scene" aria-label="A sealed birthday invitation"><div class="envelope">
      <div class="envelope-letter"><span>For you, ${name} ♡</span></div><span class="wax-seal" aria-hidden="true">♥</span>
    </div></div>
    <button class="button" data-action="open-envelope">Open Your Surprise ✨</button>
    <div class="toast" role="status" aria-live="polite"></div>
  </section>`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}

const renderers = {
  index: invitationPage,
  welcome: welcomePage,
  letter: letterPage,
  memories: memoriesPage,
  special: specialPage,
  cake: cakePage,
  gift: giftPage,
  final: finalPage
};

if (app) {
  app.innerHTML = renderers[page] ? renderers[page]() : invitationPage();
  if (page !== "index") {
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.setAttribute("role", "status");
    toast.setAttribute("aria-live", "polite");
    document.body.append(toast);
  }
  startAmbientDecor();
  revealOnScroll();
  animateEnter();
  if (page !== "memories") initMusic();
  if (page === "memories") {
    initGallery();
    initMemoriesExperience();
  }
  if (page === "cake") initCake();
  if (page === "gift") initGift();
  if (page === "final") launchFireworks(4);
  if (window.lucide) window.lucide.createIcons();
  document.querySelectorAll(".special-card").forEach((card) => {
    card.addEventListener("pointermove", (event) => {
      if (event.pointerType === "touch" || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
      const bounds = card.getBoundingClientRect();
      const rotateX = ((event.clientY - bounds.top) / bounds.height - .5) * -8;
      const rotateY = ((event.clientX - bounds.left) / bounds.width - .5) * 8;
      card.style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-4px)`;
    });
    card.addEventListener("pointerleave", () => { card.style.transform = ""; });
  });
  const revealButton = document.querySelector('[data-action="reveal-letter"]');
  if (revealButton) {
    const letter = document.querySelector("[data-letter]");
    const fullText = letter.textContent;
    letter.textContent = "";
    let timer;
    const revealFull = () => {
      window.clearInterval(timer);
      letter.textContent = fullText;
      revealButton.setAttribute("aria-expanded", "true");
      revealButton.textContent = "The whole letter, just for you 💗";
    };
    const startTyping = () => {
      let cursor = 0;
      timer = window.setInterval(() => {
        cursor = Math.min(cursor + 7, fullText.length);
        letter.textContent = fullText.slice(0, cursor);
        if (cursor >= fullText.length) window.clearInterval(timer);
      }, 18);
    };
    revealButton.addEventListener("click", revealFull);
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) revealFull();
    else window.setTimeout(startTyping, 450);
  }

  document.querySelector('[data-action="open-envelope"]')?.addEventListener("click", (event) => {
    const button = event.currentTarget;
    const envelope = document.querySelector(".envelope");
    if (button.disabled) return;
    button.disabled = true;
    button.textContent = "A little magic is on its way…";
    envelope.classList.add("is-open");
    burstConfetti(window.innerWidth / 2, window.innerHeight / 2, 48);
    window.setTimeout(() => { window.location.href = "welcome.html"; }, 1150);
  });

  document.addEventListener("click", (event) => {
    const link = event.target.closest("a[href$='.html']");
    if (!link || link.target || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || link.dataset.action === "replay") return;
    const curtain = document.querySelector(".transition-curtain");
    if (!curtain || page === "index") return;
    event.preventDefault();
    const destination = link.href;
    if (window.gsap && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      window.gsap.to(curtain, { scaleY: 1, opacity: 1, transformOrigin: "bottom", duration: .38, ease: "power2.in", onComplete: () => { window.location.href = destination; } });
    } else window.location.href = destination;
  });
}
