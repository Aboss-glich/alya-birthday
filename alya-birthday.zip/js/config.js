export const config = {
  recipientName: "Alya",
  senderName: "Your Friend",
  birthdayDate: "",
  language: "Hinglish",
  galleryPhotos: [
    "assets/images/alya-01.png", "assets/images/alya-02.png",
    "assets/images/alya-03.png", "assets/images/alya-04.png",
    "assets/images/alya-05.png"
  ],
  galleryCaptions: ["A birthday wish for Alya", "One of Alya's lovely moments", "A little smile, a little magic", "Memories with Alya", "More beautiful Alya moments"],
  galleryDates: ["Add a date", "Add a date", "Add a date", "Add a date", "Add a date"],
  alyaInstagramURL: "",
  musicTracks: [],
  socialLinks: [],
  gamingLinks: {
    playTogetherURL: "",
    playTogetherMessage: "Add a game invite link or a custom message in js/config.js."
  },
  gamingMemories: [
    { title: "Squad screenshot", image: "", caption: "Add a favourite squad screenshot.", description: "Replace this note with a squad memory." },
    { title: "Funny match moment", image: "", caption: "Add a funny match screenshot.", description: "Write down the moment everyone still laughs about." },
    { title: "Victory moment", image: "", caption: "Add a favourite match result.", description: "Add a memory from a match you want to keep." }
  ],
  groupName: "ANIME GIRLS AND BOYS GC",
  groupPhoto: "",
  groupAppreciation: "Alya, this little universe has a special place for you. Add a personal message from the group here.",
  groupMembers: [
    { name: "Friend 1 name", image: "", hiddenMessage: "Add a private birthday message from this friend." },
    { name: "Friend 2 name", image: "", hiddenMessage: "Add a private birthday message from this friend." },
    { name: "Friend 3 name", image: "", hiddenMessage: "Add a private birthday message from this friend." },
    { name: "Friend 4 name", image: "", hiddenMessage: "Add a private birthday message from this friend." }
  ],
  groupMessages: [
    "Add a funny group memory here.",
    "Add an inside joke or chat memory here.",
    "Add a little moment from the GC here."
  ],
  memoryTimeline: [
    { category: "Instagram", date: "Add a date", title: "Add a photo memory", description: "Write a caption for this moment.", image: "assets/images/alya-01.png" },
    { category: "Free Fire", date: "Add a date", title: "Add a gaming moment", description: "Write a match or squad memory.", image: "" },
    { category: "Our group", date: "Add a date", title: "Add a group memory", description: "Write a moment from the GC.", image: "" },
    { category: "Birthday", date: "Add a date", title: "Add a birthday memory", description: "Write a birthday celebration memory.", image: "" }
  ],
  surpriseMessages: ["Add a friendship message for Alya here."],
  letterContent: `Hey Alya! 💗

Kabhi-kabhi kisi ko special feel karane ke liye expensive gifts ya grand celebrations ki zaroorat nahi hoti. Sometimes, a few genuine words and a little effort are enough to make someone smile. And that's exactly what I wanted to do today.

I wanted to create something that wasn't just another birthday message copied from somewhere. Something different, something personal, something that you could explore and enjoy at your own pace.

You know, life is full of different people, different experiences and unexpected moments. Some people make ordinary days feel a little brighter simply by being themselves. And I hope you never forget the lovely qualities that make you who you are.

I genuinely wish that you get every opportunity you've been waiting for, every success you've been working towards and every happiness you deserve.

Whenever life gets busy, remember to take a moment for yourself, appreciate how far you've come and be proud of the person you're becoming.

Keep growing, keep laughing, keep exploring and most importantly, keep being YOU.

Here's to another year of beautiful possibilities.

Happy Birthday once again, Alya! 🌷`,
  specialMessages: [
    { title: "YOUR SMILE", message: "Never underestimate the happiness your smile brings.", icon: "☼" },
    { title: "YOUR KIND HEART", message: "Your kindness is one of the loveliest things about you.", icon: "♡" },
    { title: "YOUR PERSONALITY", message: "There's something unique about the way you are.", icon: "✿" },
    { title: "YOUR POSITIVE ENERGY", message: "Keep spreading happiness wherever you go.", icon: "☀" },
    { title: "YOUR DREAMS", message: "May you achieve everything your heart wishes for.", icon: "✧" },
    { title: "SIMPLY ALYA", message: "Because being yourself is already something special.", icon: "❀" }
  ],
  finalMessage: "May your difficult days become easier, your happy moments become more frequent, your dreams become closer and your confidence become stronger.",
  musicPath: "assets/audio/birthday-music.mp3",
  pages: [
    { id: "welcome", label: "Celebration", href: "welcome.html" },
    { id: "letter", label: "A letter", href: "letter.html" },
    { id: "memories", label: "Memories", href: "memories.html" },
    { id: "special", label: "You", href: "special.html" },
    { id: "cake", label: "Cake", href: "cake.html" },
    { id: "gift", label: "A gift", href: "gift.html" },
    { id: "final", label: "The end", href: "final.html" }
  ]
};
