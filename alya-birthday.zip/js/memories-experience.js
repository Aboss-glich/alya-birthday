import { config } from "./config.js";
import { burstConfetti } from "./animation-engine.js";

function announce(message) {
  const toast = document.querySelector(".toast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("is-visible");
  window.setTimeout(() => toast.classList.remove("is-visible"), 3600);
}

function localTrackSource(track) {
  const source = String(track?.src || "").trim();
  if (!source.startsWith("assets/audio/") || source.split(/[\\/]/).includes("..")) return "";
  return source;
}

function initPlayer() {
  const player = document.querySelector(".memory-player");
  if (!player) return;
  const tracks = config.musicTracks.filter((track) => track?.title && localTrackSource(track));
  const title = player.querySelector("[data-track-title]");
  const status = player.querySelector("[data-player-status]");
  const playButton = player.querySelector('[data-action="toggle-player"]');
  const previousButton = player.querySelector('[data-action="previous-track"]');
  const nextButton = player.querySelector('[data-action="next-track"]');
  const volumeControl = player.querySelector("#memory-volume");
  let audio;
  let currentTrack = 0;

  function setPlaying(playing) {
    playButton.setAttribute("aria-pressed", String(playing));
    playButton.setAttribute("aria-label", playing ? "Pause music" : "Play music");
    playButton.textContent = playing ? "Ⅱ" : "▶";
    player.classList.toggle("is-playing", playing);
  }
  function showTrack(index) {
    currentTrack = (index + tracks.length) % tracks.length;
    if (audio) {
      audio.pause();
      audio = null;
    }
    title.textContent = tracks[currentTrack].title;
    status.textContent = "Ready when you are — press play.";
    setPlaying(false);
  }
  async function togglePlayback() {
    if (!tracks.length) {
      status.textContent = "No audio added yet. Add local tracks in js/config.js.";
      announce("Add audio files under assets/audio and list them in js/config.js.");
      return;
    }
    if (audio && !audio.paused) {
      audio.pause();
      setPlaying(false);
      status.textContent = `Paused · ${tracks[currentTrack].title}`;
      return;
    }
    if (!audio) {
      audio = new Audio(tracks[currentTrack].src);
      audio.preload = "none";
      audio.volume = Number(volumeControl.value);
      audio.addEventListener("ended", () => {
        if (tracks.length > 1) showTrack(currentTrack + 1);
        else setPlaying(false);
      });
      audio.addEventListener("error", () => {
        setPlaying(false);
        status.textContent = "This track could not be loaded. Check its local file path.";
        announce("Check the track file listed in js/config.js.");
      }, { once: true });
    }
    try {
      await audio.play();
      setPlaying(true);
      status.textContent = `Now playing · ${tracks[currentTrack].title}`;
    } catch (error) {
      setPlaying(false);
      status.textContent = "This track could not be played. Check its local file path.";
      announce("Check the track file listed in js/config.js.");
      console.info("The selected local memory track could not be played.", error);
    }
  }

  if (tracks.length) {
    title.textContent = tracks[0].title;
    status.textContent = "Your memories soundtrack";
  }
  previousButton.disabled = tracks.length < 2;
  nextButton.disabled = tracks.length < 2;
  playButton.addEventListener("click", togglePlayback);
  previousButton.addEventListener("click", () => showTrack(currentTrack - 1));
  nextButton.addEventListener("click", () => showTrack(currentTrack + 1));
  volumeControl.addEventListener("input", () => {
    if (audio) audio.volume = Number(volumeControl.value);
  });
}

function initScrollMotion() {
  if (!window.gsap || !window.ScrollTrigger || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  window.gsap.registerPlugin(window.ScrollTrigger);
  window.gsap.utils.toArray(".memory-section, .surprise-section, .friendship-ending").forEach((section) => {
    window.gsap.fromTo(section, { autoAlpha: 0, y: 22 }, {
      autoAlpha: 1,
      y: 0,
      duration: .7,
      ease: "power2.out",
      scrollTrigger: { trigger: section, start: "top 86%", once: true }
    });
  });
}

function initExternalLinks() {
  document.querySelector('[data-action="instagram-link"]')?.addEventListener("click", () => {
    announce("Add Alya's Instagram profile URL in js/config.js to enable this link.");
  });
  document.querySelector('[data-action="play-together"]')?.addEventListener("click", () => {
    const message = document.querySelector("[data-game-message]");
    message.textContent = config.gamingLinks.playTogetherMessage || "Add a game invite link in js/config.js.";
    message.classList.add("is-visible");
  });
}

function initMemoryCards() {
  document.querySelectorAll(".game-memory-toggle, .friend-wish-toggle").forEach((button) => {
    button.addEventListener("click", () => {
      const card = button.closest(".game-memory, .friend-wish");
      const detail = card.querySelector(".game-note, .friend-hidden-message");
      const expanded = button.getAttribute("aria-expanded") !== "true";
      button.setAttribute("aria-expanded", String(expanded));
      detail.hidden = !expanded;
      card.classList.toggle("is-expanded", expanded);
      const label = button.querySelector(".friend-reveal-label");
      if (label) label.textContent = expanded ? "A little wish, just for you ♡" : "Tap to open ✨";
    });
  });
}

function initCardTilt() {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  document.querySelectorAll(".game-memory, .friend-wish, .timeline-card").forEach((card) => {
    card.addEventListener("pointermove", (event) => {
      if (event.pointerType === "touch") return;
      const bounds = card.getBoundingClientRect();
      const x = (event.clientX - bounds.left) / bounds.width - .5;
      const y = (event.clientY - bounds.top) / bounds.height - .5;
      card.style.setProperty("--tilt-x", `${y * -4}deg`);
      card.style.setProperty("--tilt-y", `${x * 5}deg`);
      card.classList.add("is-tilting");
    });
    card.addEventListener("pointerleave", () => {
      card.classList.remove("is-tilting");
      card.style.removeProperty("--tilt-x");
      card.style.removeProperty("--tilt-y");
    });
  });
}

function initSurpriseBox() {
  const button = document.querySelector('[data-action="open-memory-box"]');
  const reveal = document.querySelector("[data-surprise-reveal]");
  if (!button || !reveal) return;
  button.addEventListener("click", () => {
    const opened = button.getAttribute("aria-expanded") !== "true";
    button.setAttribute("aria-expanded", String(opened));
    button.setAttribute("aria-label", opened ? "Close the surprise memory box" : "Open the surprise memory box");
    reveal.hidden = !opened;
    button.classList.toggle("is-open", opened);
    if (opened) burstConfetti(window.innerWidth / 2, window.innerHeight * .55, 48);
  });
}

export function initMemoriesExperience() {
  document.body.classList.add("memories-page");
  initScrollMotion();
  initPlayer();
  initExternalLinks();
  initMemoryCards();
  initCardTilt();
  initSurpriseBox();
  document.querySelector('[data-action="replay-memories"]')?.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
  });
}
